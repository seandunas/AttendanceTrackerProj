<?php
// Get the POST data from the Android app
$email = $_POST["email"];
$password = $_POST["password"];

    // Create a new MySQLi object and connect to the database
    $conn = new mysqli("localhost", "root", "", "myit0079db");

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare the SQL query to insert the user into the table
    $stmt = $conn->prepare("INSERT INTO usertbl(email, password) VALUES (?, ?)");

    // Hash the password using the default algorithm (currently bcrypt)
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt->bind_param("ss", $email, $hashedPassword);

    // Execute the query
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
?>