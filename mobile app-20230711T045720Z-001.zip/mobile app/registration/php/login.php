<?php
// Retrieve the email and password from the request
$email = $_POST["email"];
$password = $_POST["password"];

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=localhost;dbname=myit0079db", "root", "");
    
    // Prepare the SQL statement with placeholders
    $sql = "SELECT * FROM usertbl WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    
    // Bind the email parameter
    $stmt->bindParam(":email", $email);
    
    // Execute the prepared statement
    $stmt->execute();
    
    // Fetch the result
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check if a user with the provided email exists and the password matches
    if ($user && password_verify($password, $user["password"])) {
        // Login successful
        echo 'success';
    } else {
        // Login failed
        echo 'failure';
    }
} catch (PDOException $e) {
    // Handle database connection error
    echo 'Database error: ' . $e->getMessage();
}
?>

